from aiohttp import web
from aiohttp.web_request import Request
from .config import db_block, web_routes, render_html


@web_routes.get("/action/grade/student")
async def view_student_list(request):
    return render_html(request, 'student_list.html')

@web_routes.get("/action/grade/course")
async def view_course_list(request):
    return render_html(request, 'course_list.html')

@web_routes.get("/action/grade/grade")
async def view_course_list(request):
    return render_html(request, 'grade_list.html')
